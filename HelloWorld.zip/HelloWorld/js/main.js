requirejs.config({
   // Need to set baseUrl or nested view won't work because module location relative to current url.
   // Change to the correct baseUrl when deployed to site like: http://host/myApp
   baseUrl: window.location.href.split('#')[0].substring(0, window.location.href.split('#')[0].lastIndexOf('/')) + '/js',

   // Path mappings for the logical module names
   paths: {
      'knockout': 'libs/knockout/knockout-3.3.0',
      'jquery': 'libs/jquery/jquery-2.1.3',
      'jqueryui-amd': 'libs/jquery/jqueryui-amd-1.11.4',
      'promise': 'libs/es6-promise/promise-1.0.0',
      'hammerjs': 'libs/hammer/hammer-2.0.4',
      'ojs': 'libs/oj/v1.1.2/debug',
      'ojL10n': 'libs/oj/v1.1.2/ojL10n',
      'ojtranslations': 'libs/oj/v1.1.2/resources',
      'signals': 'libs/js-signals/signals',
      'text': 'libs/require/text'
   },
   // Shim configurations for modules that do not expose AMD
   shim: {
      'jquery': {
         exports: ['jQuery', '$']
      },
      'jqueryui': {
         deps: ['jquery']
      }
   },
   // This section configures the i18n plugin. It is merging the Oracle JET built-in translation
   // resources with a custom translation file.
   // Any resource file added, must be placed under a directory named "nls". You can use a path mapping or you can define
   // a path that is relative to the location of this main.js file.
   config: {
      ojL10n: {
         merge: {
            //'ojtranslations/nls/ojtranslations': 'resources/nls/menu'
         }
      }
   }
});


/**
 * A top-level require call executed by the Application.
 * Although 'ojcore' and 'knockout' would be loaded in any case (they are specified as dependencies
 * by the modules themselves), we are listing them explicitly to get the references to the 'oj' and 'ko'
 * objects in the callback
 */
require(['ojs/ojcore', 'knockout', 'jquery', 'ojs/ojknockout', 'ojs/ojmodule', 'text'],
        function(oj, ko, $) // this callback gets executed when all required modules are loaded
{
   // Force asserts to throw an error
   oj.Assert.forceDebug();
   // Set the log level
   oj.Logger.option('level',  oj.Logger.LEVEL_INFO);
 
      
 function SimpleModel()
      {
        this.hello = ko.observable("Hello World");
      };

      $(document).ready(function ()
      {
        ko.applyBindings(new SimpleModel(), document.getElementById('div1'));
      });

});